package com;

class MyExceptions extends Exception 
{ 
    public MyExceptions(String s) 
    { 
        super(s); 
    } 
} 
public class MyException
{ 
    public static void main(String args[]) 
    { 
        try
        { 
            throw new MyExceptions("temp"); 
        } 
        catch (MyExceptions ex) 
        { 
            System.out.println("Caught"); 
            System.out.println(ex.getMessage()); 
        } 
    } 


}
