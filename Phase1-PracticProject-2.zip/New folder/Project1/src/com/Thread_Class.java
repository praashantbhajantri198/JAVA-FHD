package com;

public class Thread_Class extends Thread
{
 	public void run()
 	{
  		System.out.println(" thread started running..");
}
 	public static void main( String args[] )
 	{
 		Thread_Class mt = new Thread_Class();
  		mt.start();
 	}
}



